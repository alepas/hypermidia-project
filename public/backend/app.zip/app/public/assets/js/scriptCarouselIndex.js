$(document).ready(function(){
    $('.carousel-containera').slick({
    autoplay: true,
    autoplaySpeed: 3000,
    dots: true,
    arrows: false
    });
});